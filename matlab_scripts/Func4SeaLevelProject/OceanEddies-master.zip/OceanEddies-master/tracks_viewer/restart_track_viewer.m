if exist('hdls', 'var')
    close(hdls.fig);
    clear hdls;
end
start_track_viewer;