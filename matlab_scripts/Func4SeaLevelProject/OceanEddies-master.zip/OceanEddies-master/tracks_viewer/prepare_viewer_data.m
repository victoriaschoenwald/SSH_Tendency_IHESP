urlwrite('http://gofc.cs.umn.edu/eddy_project/tracks_viewer_data.zip', 'tracks_viewer_data.zip');
unzip('tracks_viewer_data.zip');